using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 150;
    private int currentHealth;
    public HealthBar healthBar;
    public Text deathText;
    public GameManager gameManager;

    void Start()
    {
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
        deathText.enabled = false;
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth < 0)
        {
            currentHealth = 0;
        }
        healthBar.SetHealth(currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        gameObject.SetActive(false);

        // 顯示死亡提示
        deathText.enabled = true;
        deathText.text = "You Died";
        Invoke("RestartGame", 5f);
    }
    void RestartGame()
    {
        gameManager.RestartGame();
    }
}