using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Trap : MonoBehaviour
{

    private void OnCillisionEnter(Collison collsion)
    {
        //SceneManager.LoadScene("Level01")
        FindObjectOfType<Scorekeeper>().AddScore();
        Destroy(gameObject);
    }
    //If I collide, restart the level.
}