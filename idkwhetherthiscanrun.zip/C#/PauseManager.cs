using UnityEngine;

public class PauseManager : MonoBehaviour
{
    private bool isPaused = false;

    void Update()
    {
        // 使用Tab鍵來暫停和恢復遊戲
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            TogglePause();
        }
    }

    public void PauseGame()
    {
        Time.timeScale = 0f; // 將時間縮放設置為0，暫停遊戲
        isPaused = true;
    }

    public void ResumeGame()
    {
        Time.timeScale = 1f; // 將時間縮放設置為1，恢復遊戲
        isPaused = false;
    }

    public void TogglePause()
    {
        if (isPaused)
        {
            ResumeGame();
        }
        else
        {
            PauseGame();
        }
    }
}
