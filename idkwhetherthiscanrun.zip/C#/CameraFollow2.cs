using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target; 
     // 相機與目標的偏移量
    public Vector3 offset;
    public float smoothSpeed = 0.2f; 

    void LateUpdate()
    {
        Vector3 desiredPosition = target.position + offset; 
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed); 
        // 更新相機位置
        transform.position = smoothedPosition; 
    }
}
