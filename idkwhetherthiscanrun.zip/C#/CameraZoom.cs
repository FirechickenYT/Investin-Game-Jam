using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    public float zoomSpeed = 1.5f; 
    public float minZoom = 5f; 
    public float maxZoom = 10f; 

    private Camera cam;

    void Start()
    {
        cam = GetComponent<Camera>();
    }

    void Update()
    {
        float scrollData = Input.GetAxis("Mouse ScrollWheel"); 
        // 獲取當前相機的正交大小
        float size = cam.orthographicSize; 

        size -= scrollData * zoomSpeed; 
        size = Mathf.Clamp(size, minZoom, maxZoom); 

        cam.orthographicSize = size; 
    }
}
