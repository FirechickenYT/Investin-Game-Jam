using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    private float timeElapsed = 0f; 
    public Text timeText; 

    void Update()
    {
         // 增加經過的時間
        timeElapsed += Time.deltaTime;
        // 顯示時間
        DisplayTime(timeElapsed); 
    }

    void DisplayTime(float timeToDisplay)
    {
        float minutes = Mathf.FloorToInt(timeToDisplay / 60); 
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        float milliseconds = (timeToDisplay % 1) * 1000;

        timeText.text = string.Format("{0:00}:{1:00}:{2:000}", minutes, seconds, Mathf.FloorToInt(milliseconds));
    }
}
